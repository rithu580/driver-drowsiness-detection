package com.example.driverdrowsinessalert

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.telephony.SmsManager
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.net.toUri
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class DrowsinessService : Service() {

    private lateinit var alarmPlayer: MediaPlayer
    private lateinit var voicePlayer: MediaPlayer
    private val handler = Handler(Looper.getMainLooper())

    private val ref = FirebaseDatabase.getInstance()
        .getReference("drivers/driver_1")

    private var alertTriggered = false
    private var smsSent = false

    // Location
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var lat = 0.0
    private var lon = 0.0

    override fun onCreate() {
        super.onCreate()

        startForegroundProper()
        initPlayers()
        initLocation()
        listenFirebase()
    }

    /* ---------------- PLAYERS ---------------- */

    private fun initPlayers() {
        alarmPlayer = MediaPlayer.create(this, R.raw.alarm).apply {
            isLooping = true
        }
        voicePlayer = MediaPlayer.create(this, R.raw.voice_alert)
    }

    /* ---------------- FIREBASE ---------------- */

    private fun listenFirebase() {
        ref.child("status").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val status = snapshot.getValue(String::class.java)?.trim()

                if (status == "DROWSY" && !alertTriggered) {
                    alertTriggered = true
                    startAlarm()

                    handler.postDelayed({
                        verifyAndTrigger()
                    }, 15000) // ⏱ 15 sec delay

                } else if (status == "NORMAL") {
                    resetAll()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("DrowsyService", error.message)
            }
        })
    }

    private fun verifyAndTrigger() {
        ref.child("status").get().addOnSuccessListener {
            if (it.getValue(String::class.java) == "DROWSY") {

                showAlertUI()
                playVoice()

                handler.postDelayed({
                    sendSMS()
                    startEmergencyCall()
                }, 4000)
            }
        }
    }

    /* ---------------- ACTIONS ---------------- */

    private fun startAlarm() {
        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        audio.setStreamVolume(
            AudioManager.STREAM_ALARM,
            audio.getStreamMaxVolume(AudioManager.STREAM_ALARM),
            0
        )
        if (!alarmPlayer.isPlaying) alarmPlayer.start()
    }

    private fun playVoice() {
        voicePlayer.start()
    }

    private fun showAlertUI() {
        val i = Intent(this, AlertActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    /**
     * Initiates an emergency phone call to a predefined contact number.
     *
     * This function checks for the [Manifest.permission.CALL_PHONE] permission before proceeding.
     * If permission is granted, it creates an [Intent.ACTION_CALL] intent with the
     * specific telephone number and starts the activity.
     *
     * @see Manifest.permission.CALL_PHONE
     * @see Intent.ACTION_CALL
     */
    private fun startEmergencyCall() {
        if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.CALL_PHONE
            ) != PackageManager.PERMISSION_GRANTED
        ) return

        val intent = Intent(Intent.ACTION_CALL)
        intent.data = "tel:8056588064".toUri()
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    @Suppress("DEPRECATION")
    private fun sendSMS() {
        if (smsSent) return
        if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.SEND_SMS
            ) != PackageManager.PERMISSION_GRANTED
        ) return

        val msg = "🚨 Driver drowsy!\nhttps://maps.google.com/?q=$lat,$lon"
        SmsManager.getDefault()
            .sendTextMessage("8056588064", null, msg, null, null)

        smsSent = true
    }

    private fun resetAll() {
        alertTriggered = false
        smsSent = false

        if (alarmPlayer.isPlaying) {
            alarmPlayer.pause()
            alarmPlayer.seekTo(0)
        }
        if (voicePlayer.isPlaying) voicePlayer.pause()
    }

    /* ---------------- LOCATION ---------------- */

    private fun initLocation() {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        val req = LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY, 5000
        ).build()

        if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            fusedLocationClient.requestLocationUpdates(
                req,
                object : LocationCallback() {
                    override fun onLocationResult(r: LocationResult) {
                        r.lastLocation?.let {
                            lat = it.latitude
                            lon = it.longitude
                        }
                    }
                },
                Looper.getMainLooper()
            )
        }
    }

    /* ---------------- FOREGROUND ---------------- */

    private fun startForegroundProper() {
        val id = "drowsy_channel"

        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                id, "Drowsiness Alert",
                NotificationManager.IMPORTANCE_HIGH
            )
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }

        val notif = NotificationCompat.Builder(this, id)
            .setContentTitle("Driver Monitoring Active")
            .setSmallIcon(R.mipmap.ic_launcher)
            .build()

        startForeground(1, notif)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
